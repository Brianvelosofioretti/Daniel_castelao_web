<!-- SOCIAL MEDIA + SEARCH -->
<div class="search sf_container">
	<form class="searchform" method="post" action="<?php echo esc_url( home_url( '/' ) ); ?>">
		<fieldset class="sf_search">
			<input type="text" class="field sf_input" name="s" value="" style="float: left;" />
			<input type="submit" class="button" name="send" value="Search" />
		</fieldset>
	</form>
</div>
<!-- /SOCIAL MEDIA + SEARCH -->