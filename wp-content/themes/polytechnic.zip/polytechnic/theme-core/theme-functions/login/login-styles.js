jQuery(document).ready(function($) {

var winWidth = window.innerWidth;

$('#section-login-footer').css("width", winWidth);

});